# You Spin Me Round Robin

This project consists of making a round-robin scheduling algorithm in C. The scheduler will calculate and output the average waiting and response times for a given workload and quantum length.

## Building

```shell
make
```

## Running

cmd for running TODO
```shell
./rr.c processes.txt 3
```

results TODO
```shell
Example output: Average waiting time: 7:00 Average response time: 2.75

```

## Cleaning up

```shell
make clean
```
